from collections import defaultdict
import re
import sys 

inf = 0x3f3f3f3f
dist = dict()
graph = defaultdict(list)
pre = dict()

def makeGraph(edges):
    
    for edge in edges:  
        u, v, color, method = edge.split(' ')
        graph[u].append((v, color, method))
        graph[v].append((u, color, method))
        dist[(u, v)] = dist[(v, u)]= inf
        pre[(u, v)] = pre[(v, u)] = (-1, -1)
    
        
def findShortestPath(st, ed):
    dist[(st, st)] = 0 
    qf = qb = 0
    q = []
    
    for v, color, method in graph[st]:
        q.append((st, v, color, method))
        qb = qb + 1
        dist[(st, v)] = 1
        if v == ed:
            return (st, ed)
        pre[(st, v)] = (-1, -1)
        
    flag = 0
    while qf < qb:
        u, v, color, method = q[qf]
        if v == ed: flag = 1;
        qf = qf + 1
        
        for x, _color, _method in graph[v]:
            if x == u: continue 
            if (color != _color and _method != method) : continue
            if dist[(v, x)] < dist[(u, v)] + 1 : continue
            if dist[(v, x)] == dist[(u, v)] + 1:
                a, b = pre[(v, x)]
                if a < u: continue
            dist[(v, x)] = dist[(u, v)] + 1
            q.append((v, x, _color, _method))
            qb = qb + 1
            pre[(v, x)] = (u, v) 
            
    if(flag == 0): return "NO PATH"
    
    mn = inf
    t = ed
    for u, color, method in graph[ed]:
        if mn > dist[(u, ed)]: t = u
        
    path = []
    path.append(ed)
    a = t
    b = ed;
    while a != -1:
        path.append(a)
        a, b = pre[(a, b)]
        
    path.reverse()
    return path   


def readFile(fileName):
    lines = []
    with open(fileName) as data:
        for line in data: lines.append(line.strip('\n'))
    firstLine = re.split(' ', lines[0])
    return firstLine[2], firstLine[3], lines[1:]


st, ed, edges = readFile(sys.argv[1])
makeGraph(edges) 
print(findShortestPath(st, ed))
